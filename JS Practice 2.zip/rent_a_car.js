window.addEventListener("load", () => {
    document.querySelector("#fdate").valueAsDate = new Date();
    document.querySelector("#sdate").valueAsDate = new Date();
});
  


function submit() {

    var info = {};

    info.fname = document.getElementById('fname').value;
    info.lname = document.getElementById('lname').value;
    info.typeA = document.getElementById('typeA').value;
    info.typeB = document.getElementById('typeB').value;
    info.fdate = new Date(document.querySelector("#fdate").value);
    info.sdate = new Date(document.querySelector("#sdate").value);
    info.datesDiff = Math.abs(sdate - fdate);
    info.numberOfDays = Math.ceil(datesDiff / (1000 * 60 * 60 * 24));


    if (info.fname == "" || info.lname == "") {
        alert(`Please fill out ALL fields`)
    }

    var fname = document.getElementById('fname').value;
    var lname = document.getElementById('lname').value;
    var type = document.getElementsByName('types').value;
    
    var fdate = new Date(document.querySelector("#fdate").value);
    var sdate = new Date(document.querySelector("#sdate").value);

    var datesDiff = Math.abs(sdate - fdate);
    var numberOfDays = Math.ceil(datesDiff / (1000 * 60 * 60 * 24));

    

    //Local storage
    localStorage.setItem('First Name', fname);
    localStorage.setItem('Last Name', lname);
    localStorage.setItem('Type A', typeA);
    localStorage.setItem('Type B', typeB);
    localStorage.setItem('Pick-up Date', fdate);
    localStorage.setItem('Drop Off Date', sdate);
    localStorage.setItem('Difference of Date', datesDiff);
    localStorage.setItem('Number of Days', numberOfDays);
    

    localStorage.setItem('Info', JSON.stringify(info));
}

function showInfo() {
    
    var info = {};

    info.fname = document.getElementById('fname').value;
    info.lname = document.getElementById('lname').value;
    info.type = document.getElementsByName('types').value;
    info.fdate = new Date(document.querySelector("#fdate").value);
    info.sdate = new Date(document.querySelector("#sdate").value);


    if (info.fname == "" || info.lname == "") {
        alert('Please fill out ALL fields')
    } else {
        open('info_page.html', target='_self')
    }
    
    
}

