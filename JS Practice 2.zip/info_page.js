window.addEventListener("load", () => {
    
    var formLocalStorage = JSON.parse(localStorage.getItem('Info'));

    let discount;
    let amount = localStorage.getItem('Number of Days') * 15;
    let num;
    let payment;

    if (localStorage.getItem('Number of Days') > 15) {
        discount = 10;
        num = amount / discount;
        payment = amount - num;
    } if (localStorage.getItem('Number of Days') < 15) {
        discount = 0;
        payment = amount
    }

    if (formLocalStorage === null) {
        document.getElementById('data').innerHTML = 'Sorry no data to show!'
    } else {
        document.getElementById('data').innerHTML = 
                `<b>First Name:</b> ${localStorage.getItem('First Name')} <br><br>
                <b>Last Name:</b> ${formLocalStorage.lname} <br><br>
                <b>Number of Days:</b> ${localStorage.getItem('Number of Days')} <br><br>
                <b>Discount:</b> ${discount}% <br><br>
                <b>Amount needed to pay:</b> ${payment.toFixed(2)}$`
    }
})

function goBack() {
    open('rent_a_car.html', target='_self')
}